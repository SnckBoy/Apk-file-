# MYRAA Source Recovered

Recovered from `MYRAA-Mobile-OPTIMIZED-v1.0.2.apk`.

## Included
- `web/index.html` — packaged HTML entry point.
- `web/assets/app.bundle.js` — production JavaScript bundle containing the React application logic.
- `web/assets/app.bundle.css` — production CSS bundle.
- `web/*.mp4` — packaged MYRAA animation/video assets.
- `server/server.embedded.ts` — TypeScript/Node server source embedded inside the JavaScript bundle and extracted.
- `capacitor.config.json` — packaged Capacitor configuration.
- `capacitor.plugins.json` — packaged plugin metadata.
- `metadata/native-bridge.js` — packaged native bridge script.
- `android-apk-extracted/` — raw APK contents for reference.

## Important limitation
An APK is a compiled distribution, not the original development repository. Original React component/module filenames, TypeScript source maps, package-lock data, build configuration, and comments are not necessarily recoverable. The application bundle is therefore preserved rather than falsely presented as the original source tree.

The embedded server source is more directly reconstructable because the bundle contains that source as a string.

## Rebuild note
The recovered web bundle can be served as static web content. Reconstructing a clean Vite/React/Capacitor development repository requires recreating the missing build metadata and separating bundled modules.
